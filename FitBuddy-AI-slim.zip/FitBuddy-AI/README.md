# FitBuddy - AI Fitness Plan Generator

Generates personalized 7-day workout plans and nutrition tips with Google Gemini models. Built with FastAPI, SQLite (SQLAlchemy), Jinja2 templates, HTML and CSS.

## Features
- 7-day workout plan (Gemini Pro) and nutrition tip (Gemini Flash)
- Feedback box that revises the plan with AI
- Admin page to view and delete users
- Built-in fallback text when no API key is set

## Run locally (Windows)
```
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000

Add your Gemini API key to `.env` as `GOOGLE_API_KEY=...` (never commit `.env`).
