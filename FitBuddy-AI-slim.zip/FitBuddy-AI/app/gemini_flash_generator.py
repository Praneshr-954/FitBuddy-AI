"""
Generates a short, practical nutrition/recovery tip using a lightweight
Gemini "Flash"-class model (configurable via GEMINI_FLASH_MODEL, defaults
to gemini-2.0-flash).
"""

import os

import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
GEMINI_FLASH_MODEL = os.getenv("GEMINI_FLASH_MODEL", "gemini-2.0-flash")

if GOOGLE_API_KEY:
    genai.configure(api_key=GOOGLE_API_KEY)


def generate_nutrition_tip_with_flash(goal: str) -> str:
    """
    Ask Gemini Flash for a concise nutrition or recovery tip tied to the
    user's fitness goal. Falls back to a static tip if no API key is
    configured or the request fails.
    """
    if not GOOGLE_API_KEY:
        return _fallback_tip(goal)

    prompt = f"""You are a sports nutrition coach. In 2-3 sentences, give one
practical nutrition or recovery tip for someone whose fitness goal is:
"{goal}". Keep it concise, actionable, and encouraging. Plain text only."""

    try:
        model = genai.GenerativeModel(GEMINI_FLASH_MODEL)
        response = model.generate_content(prompt)
        text = (getattr(response, "text", None) or "").strip()
        return text if text else _fallback_tip(goal)
    except Exception:  # noqa: BLE001 - degrade gracefully to the fallback tip
        return _fallback_tip(goal)


def _fallback_tip(goal: str) -> str:
    return (
        f"For your goal of '{goal}', include a protein source in every meal "
        "(chicken, fish, beans, or Greek yogurt) and drink plenty of water "
        "throughout the day to support recovery."
    )