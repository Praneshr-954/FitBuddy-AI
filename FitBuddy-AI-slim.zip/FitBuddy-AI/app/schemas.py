"""
Pydantic models used to validate data flowing through FitBuddy's routes.
"""

from pydantic import BaseModel, Field


class UserInput(BaseModel):
    """Validated payload for the '/generate-workout' route."""

    username: str = Field(..., min_length=1, max_length=100)
    user_id: str = Field(..., min_length=1, max_length=100)
    age: int = Field(..., ge=10, le=100)
    weight: float = Field(..., gt=0, le=400)
    goal: str = Field(..., min_length=1, max_length=100)
    intensity: str = Field(..., min_length=1, max_length=20)


class FeedbackRequest(BaseModel):
    """Validated payload for the '/submit-feedback' route."""

    user_id: str = Field(..., min_length=1, max_length=100)
    feedback: str = Field(..., min_length=1, max_length=1000)