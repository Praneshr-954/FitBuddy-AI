"""
Generates the 7-day workout plan using a Gemini "Pro"-class model
(configurable via GEMINI_PRO_MODEL, defaults to gemini-2.5-pro).
"""

import os

import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
GEMINI_PRO_MODEL = os.getenv("GEMINI_PRO_MODEL", "gemini-2.5-pro")

if GOOGLE_API_KEY:
    genai.configure(api_key=GOOGLE_API_KEY)


def generate_workout_gemini(goal: str, intensity: str, age: int = None, weight: float = None) -> str:
    """
    Ask Gemini for a structured 7-day workout plan tailored to the user's
    goal and intensity. Falls back to a static plan if no API key is
    configured or the request fails, so the app keeps working end-to-end
    even without live AI access.
    """
    if not GOOGLE_API_KEY:
        return _fallback_plan(goal, intensity)

    prompt = f"""You are a certified personal fitness coach. Create a structured
7-day workout plan for a client with the following profile:

- Fitness goal: {goal}
- Workout intensity: {intensity}
- Age: {age if age is not None else "not specified"}
- Weight: {f"{weight} kg" if weight is not None else "not specified"}

Requirements:
- Cover Day 1 through Day 7, including one rest or active-recovery day.
- For each day, include a short warm-up, the main workout (exercise names
  with sets/reps or duration), and a brief cooldown.
- Keep the tone motivating but concise.
- Format the response as clean plain text with a clear heading for each
  day (e.g. "Day 1: Full Body Strength").
"""

    try:
        model = genai.GenerativeModel(GEMINI_PRO_MODEL)
        response = model.generate_content(prompt)
        text = (getattr(response, "text", None) or "").strip()
        return text if text else _fallback_plan(goal, intensity)
    except Exception as exc:  # noqa: BLE001 - surface any provider error gracefully
        return (
            f"{_fallback_plan(goal, intensity)}\n\n"
            f"(Note: live AI generation failed, showing a fallback plan instead. Details: {exc})"
        )


def _fallback_plan(goal: str, intensity: str) -> str:
    return (
        f"7-Day Fallback Workout Plan (Goal: {goal}, Intensity: {intensity})\n\n"
        "Day 1: Full Body Strength - Warm-up 5 min, Squats/Push-ups/Rows 3x12, Cooldown stretch\n"
        "Day 2: Cardio + Core - Warm-up 5 min, 20 min steady cardio, Plank/Crunches 3x, Cooldown stretch\n"
        "Day 3: Active Recovery - Light walk, mobility, and stretching\n"
        "Day 4: Upper Body Strength - Warm-up 5 min, Bench/Rows/Shoulders 3x10, Cooldown stretch\n"
        "Day 5: Lower Body Strength - Warm-up 5 min, Lunges/Deadlifts/Calf raises 3x12, Cooldown stretch\n"
        "Day 6: Cardio Intervals - Warm-up 5 min, 6x1 min sprint/1 min walk, Cooldown stretch\n"
        "Day 7: Rest\n"
    )