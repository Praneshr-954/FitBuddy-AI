"""
All HTTP routes for FitBuddy.

Routes
------
GET  /                    -> input form (index.html)
POST /generate-workout    -> generates plan + tip, saves them, shows result.html
POST /submit-feedback     -> revises the plan based on feedback, shows result.html
GET  /view-all-users      -> admin dashboard (all_users.html)
POST /delete-user/{id}    -> removes a user + their plan, redirects to admin dashboard
"""

import os

from fastapi import APIRouter, Form, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from pydantic import ValidationError

from app import database
from app.gemini_flash_generator import generate_nutrition_tip_with_flash
from app.gemini_generator import generate_workout_gemini
from app.schemas import FeedbackRequest, UserInput
from app.updated_plan import update_workout_plan


BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEMPLATE_DIR = os.path.join(BASE_DIR, "templates")

templates = Jinja2Templates(directory=TEMPLATE_DIR)
templates.env.cache = None

router = APIRouter()


@router.get("/")
async def index(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={},
    )


@router.post("/generate-workout")
async def generate_workout(
    request: Request,
    username: str = Form(...),
    user_id: str = Form(...),
    age: int = Form(...),
    weight: float = Form(...),
    goal: str = Form(...),
    intensity: str = Form(...),
):
    try:
        user_input = UserInput(
            username=username,
            user_id=user_id,
            age=age,
            weight=weight,
            goal=goal,
            intensity=intensity,
        )
    except ValidationError as exc:
        return templates.TemplateResponse(
            request=request,
            name="result.html",
            context={
                "error": f"Invalid input: {exc.errors()[0]['msg']}",
            },
            status_code=422,
        )

    try:
        workout_plan = generate_workout_gemini(
            goal=user_input.goal,
            intensity=user_input.intensity,
            age=user_input.age,
            weight=user_input.weight,
        )

        nutrition_tip = generate_nutrition_tip_with_flash(
            goal=user_input.goal
        )

    except Exception as exc:
        return templates.TemplateResponse(
            request=request,
            name="result.html",
            context={
                "error": (
                    "Unable to generate your workout plan right now. "
                    "Please try again later."
                ),
            },
            status_code=503,
        )

    try:
        database.save_user(
            user_id=user_input.user_id,
            username=user_input.username,
            age=user_input.age,
            weight=user_input.weight,
            goal=user_input.goal,
            intensity=user_input.intensity,
        )

        database.save_plan(
            user_id=user_input.user_id,
            original_plan=workout_plan,
            nutrition_tip=nutrition_tip,
        )

    except Exception:
        return templates.TemplateResponse(
            request=request,
            name="result.html",
            context={
                "error": (
                    "Your workout plan was generated, but it could not be "
                    "saved to the database."
                ),
            },
            status_code=500,
        )

    return templates.TemplateResponse(
        request=request,
        name="result.html",
        context={
            "username": user_input.username,
            "user_id": user_input.user_id,
            "age": user_input.age,
            "weight": user_input.weight,
            "goal": user_input.goal,
            "intensity": user_input.intensity,
            "workout_plan": workout_plan,
            "nutrition_tip": nutrition_tip,
            "updated_plan": None,
            "feedback": None,
        },
    )


@router.post("/submit-feedback")
async def submit_feedback(
    request: Request,
    user_id: str = Form(...),
    feedback: str = Form(...),
):
    try:
        feedback_request = FeedbackRequest(
            user_id=user_id,
            feedback=feedback,
        )
    except ValidationError as exc:
        return templates.TemplateResponse(
            request=request,
            name="result.html",
            context={
                "error": f"Invalid input: {exc.errors()[0]['msg']}",
            },
            status_code=422,
        )

    try:
        user = database.get_user(feedback_request.user_id)
        original_plan = database.get_original_plan(
            feedback_request.user_id
        )

    except Exception:
        return templates.TemplateResponse(
            request=request,
            name="result.html",
            context={
                "error": "Unable to retrieve your saved workout plan.",
            },
            status_code=500,
        )

    if not user or not original_plan:
        return templates.TemplateResponse(
            request=request,
            name="result.html",
            context={
                "error": (
                    "No existing plan was found for that User ID. "
                    "Please generate a plan first."
                ),
            },
            status_code=404,
        )

    try:
        updated_plan_text = update_workout_plan(
            original_plan=original_plan,
            feedback=feedback_request.feedback,
            goal=user.goal,
            intensity=user.intensity,
        )

        database.update_plan(
            feedback_request.user_id,
            updated_plan_text,
        )

        nutrition_tip = generate_nutrition_tip_with_flash(
            goal=user.goal
        )

    except Exception:
        return templates.TemplateResponse(
            request=request,
            name="result.html",
            context={
                "error": (
                    "Unable to update your workout plan right now. "
                    "Please try again later."
                ),
            },
            status_code=503,
        )

    return templates.TemplateResponse(
        request=request,
        name="result.html",
        context={
            "username": user.username,
            "user_id": user.user_id,
            "age": user.age,
            "weight": user.weight,
            "goal": user.goal,
            "intensity": user.intensity,
            "workout_plan": original_plan,
            "updated_plan": updated_plan_text,
            "nutrition_tip": nutrition_tip,
            "feedback": feedback_request.feedback,
        },
    )


@router.get("/view-all-users")
async def view_all_users(request: Request):
    try:
        users = database.get_all_users_with_plans()

    except Exception:
        return templates.TemplateResponse(
            request=request,
            name="all_users.html",
            context={
                "users": [],
                "error": "Unable to load user records from the database.",
            },
            status_code=500,
        )

    return templates.TemplateResponse(
        request=request,
        name="all_users.html",
        context={
            "users": users,
        },
    )


@router.post("/delete-user/{user_id}")
async def delete_user(user_id: str):
    database.delete_user(user_id)

    return RedirectResponse(
        url="/view-all-users",
        status_code=303,
    )