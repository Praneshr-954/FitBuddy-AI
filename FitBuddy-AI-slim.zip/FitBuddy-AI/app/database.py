"""
SQLite persistence layer for FitBuddy, built with SQLAlchemy.

Tables
------
users : one row per registered user (name, age, weight, goal, intensity)
plans : one row per user's plan (original plan, updated plan, nutrition tip)

Every public helper opens its own short-lived session and returns plain
data (ORM objects with already-loaded scalar columns, or dicts), so callers
never need to manage sessions themselves.
"""

import os

from sqlalchemy import Column, Float, ForeignKey, Integer, String, Text, create_engine
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "fitbuddy.db")
DATABASE_URL = f"sqlite:///{DB_PATH}"

# check_same_thread=False is required because FastAPI may serve a request
# on a different thread than the one that created the engine.
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})

# expire_on_commit=False keeps attribute values readable on objects that are
# returned to callers after their session has already been closed.
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False)

Base = declarative_base()


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String(100), unique=True, index=True, nullable=False)
    username = Column(String(100), nullable=False)
    age = Column(Integer, nullable=False)
    weight = Column(Float, nullable=False)
    goal = Column(String(100), nullable=False)
    intensity = Column(String(20), nullable=False)

    plan = relationship("Plan", back_populates="user", uselist=False, cascade="all, delete-orphan")


class Plan(Base):
    __tablename__ = "plans"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String(100), ForeignKey("users.user_id"), unique=True, nullable=False)
    original_plan = Column(Text, nullable=False)
    updated_plan = Column(Text, nullable=True)
    nutrition_tip = Column(Text, nullable=True)

    user = relationship("User", back_populates="plan")


def init_db() -> None:
    """Create all tables if they don't already exist. Safe to call repeatedly."""
    Base.metadata.create_all(bind=engine)


def _session():
    return SessionLocal()


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------

def save_user(user_id: str, username: str, age: int, weight: float, goal: str, intensity: str) -> User:
    """Insert a new user, or update the existing one for the same user_id."""
    session = _session()
    try:
        user = session.query(User).filter(User.user_id == user_id).first()
        if user:
            user.username = username
            user.age = age
            user.weight = weight
            user.goal = goal
            user.intensity = intensity
        else:
            user = User(
                user_id=user_id,
                username=username,
                age=age,
                weight=weight,
                goal=goal,
                intensity=intensity,
            )
            session.add(user)
        session.commit()
        session.refresh(user)
        return user
    finally:
        session.close()


def get_user(user_id: str):
    session = _session()
    try:
        return session.query(User).filter(User.user_id == user_id).first()
    finally:
        session.close()


def get_all_users():
    session = _session()
    try:
        return session.query(User).all()
    finally:
        session.close()


def delete_user(user_id: str) -> bool:
    session = _session()
    try:
        user = session.query(User).filter(User.user_id == user_id).first()
        if not user:
            return False
        session.delete(user)
        session.commit()
        return True
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Plans
# ---------------------------------------------------------------------------

def save_plan(user_id: str, original_plan: str, nutrition_tip: str) -> Plan:
    """Create (or overwrite) the plan for a user, resetting any previous update."""
    session = _session()
    try:
        plan = session.query(Plan).filter(Plan.user_id == user_id).first()
        if plan:
            plan.original_plan = original_plan
            plan.nutrition_tip = nutrition_tip
            plan.updated_plan = None
        else:
            plan = Plan(user_id=user_id, original_plan=original_plan, nutrition_tip=nutrition_tip)
            session.add(plan)
        session.commit()
        session.refresh(plan)
        return plan
    finally:
        session.close()


def update_plan(user_id: str, updated_plan_text: str):
    session = _session()
    try:
        plan = session.query(Plan).filter(Plan.user_id == user_id).first()
        if plan:
            plan.updated_plan = updated_plan_text
            session.commit()
            session.refresh(plan)
        return plan
    finally:
        session.close()


def get_original_plan(user_id: str):
    session = _session()
    try:
        plan = session.query(Plan).filter(Plan.user_id == user_id).first()
        return plan.original_plan if plan else None
    finally:
        session.close()


def get_all_plans():
    session = _session()
    try:
        return session.query(Plan).all()
    finally:
        session.close()


def get_all_users_with_plans():
    """
    Convenience helper for the admin view: returns a list of plain dicts
    (not ORM objects) combining each user with their plan, so templates can
    render everything without touching a closed session.
    """
    session = _session()
    try:
        users = session.query(User).all()
        rows = []
        for user in users:
            plan = session.query(Plan).filter(Plan.user_id == user.user_id).first()
            rows.append(
                {
                    "user_id": user.user_id,
                    "username": user.username,
                    "age": user.age,
                    "weight": user.weight,
                    "goal": user.goal,
                    "intensity": user.intensity,
                    "original_plan": plan.original_plan if plan else None,
                    "updated_plan": plan.updated_plan if plan else None,
                    "nutrition_tip": plan.nutrition_tip if plan else None,
                }
            )
        return rows
    finally:
        session.close()