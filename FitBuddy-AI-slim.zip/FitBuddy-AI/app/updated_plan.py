"""
Revises an existing workout plan based on the user's free-text feedback,
using the same Gemini "Pro"-class model as the initial generation.
"""

import os

import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
GEMINI_PRO_MODEL = os.getenv("GEMINI_PRO_MODEL", "gemini-2.5-pro")

if GOOGLE_API_KEY:
    genai.configure(api_key=GOOGLE_API_KEY)


def update_workout_plan(original_plan: str, feedback: str, goal: str = "", intensity: str = "") -> str:
    """
    Send the original plan and the user's feedback to Gemini and return a
    revised 7-day plan. Falls back to appending a note to the original plan
    if no API key is configured or the request fails.
    """
    if not GOOGLE_API_KEY:
        return f"{original_plan}\n\n[Feedback received, but live AI update is unavailable without an API key]\nFeedback: {feedback}"

    prompt = f"""You are a certified fitness coach. A client has an existing
7-day workout plan and has given feedback on it. Revise the plan to
incorporate their feedback while staying aligned with their original goal
({goal or "not specified"}) and intensity ({intensity or "not specified"}).

Original plan:
{original_plan}

Client feedback:
{feedback}

Return the full revised 7-day plan in the same clean, day-by-day plain text
format as the original (Day 1 through Day 7)."""

    try:
        model = genai.GenerativeModel(GEMINI_PRO_MODEL)
        response = model.generate_content(prompt)
        text = (getattr(response, "text", None) or "").strip()
        return text if text else original_plan
    except Exception as exc:  # noqa: BLE001 - degrade gracefully
        return f"{original_plan}\n\n(Note: live AI update failed, showing the original plan. Details: {exc})"