"""
FitBuddy - AI Fitness Plan Generator (FastAPI entry point).

Run from the project root with:
    uvicorn app.main:app --reload

Then open:
    http://127.0.0.1:8000        (app)
    http://127.0.0.1:8000/docs   (interactive API docs)
"""

import os

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app import database
from app.routes import router

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATIC_DIR = os.path.join(BASE_DIR, "static")

app = FastAPI(
    title="FitBuddy - AI Fitness Plan Generator",
    description="Generates personalized 7-day workout plans and nutrition tips using Google Gemini models.",
    version="1.0.0",
)

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.on_event("startup")
async def on_startup() -> None:
    database.init_db()


app.include_router(router)